# PES arayüz dönüşümü — uygulama planı

Bu klasör repo yapısını aynen yansıtır. Dosyaları kendi yollarına kopyala, sonra ekranları
sırayla dönüştür. Her adım bağımsız çalışır ve tek başına deploy edilebilir; büyük bir
"her şeyi birden değiştir" adımı yok.

```
handoff/
  app/globals.css                       → app/globals.css              (değiştir)
  lib/ui/tone.ts                        → lib/ui/tone.ts               (yeni)
  components/ui/*                       → components/ui/*              (yeni)
  components/pes/WorkshopsTable.tsx     → components/pes/…             (yeni, referans)
  app/pes/workshops/page.tsx            → app/pes/workshops/page.tsx   (referans dönüşüm)
```

---

## Adım 0 — globals.css (15 dakika)

`app/globals.css` dosyasını buradaki sürümle değiştir. İki şey yapar:

1. **`body { font-family: Arial… }` satırını kaldırır.** `layout.tsx` Geist'i yüklüyordu ama
   bu satır onu eziyordu. Tek satırlık değişiklik, tüm ekranlarda görünür fark.
2. **Token'ları `@theme inline` içinde tanımlar.** Artık `bg-accent`, `text-ink`,
   `border-line`, `text-faint`, `bg-warn-soft` gibi sınıflar çalışır.

Eski `--color-pes-accent` üçlüsü alias olarak korundu, yani migrasyon bitene kadar
`bg-pes-accent` kullanan yerler bozulmaz. Tüm ekranlar dönüştükten sonra o üç satırı sil.

**Kontrol:** `npm run dev`, herhangi bir sayfa. Yazı tipi Arial değil Geist görünmeli.

### Bul-değiştir (tek seferde, güvenli)

| Ara | Yaz |
| --- | --- |
| `bg-[#197A56]` | `bg-accent` |
| `hover:bg-[#0E3E1B]`, `hover:bg-[#145e42]` | `hover:bg-accent-hover` |
| `text-[#197A56]` | `text-accent` |
| `border-[#197A56]` | `border-accent` |
| `text-gray-900`, `text-slate-900` | `text-ink` |
| `text-gray-600`, `text-slate-600` | `text-muted` |
| `text-gray-400`, `text-gray-500`, `text-slate-500` | `text-faint` |
| `border-gray-200`, `border-slate-200` | `border-line-soft` |
| `border-gray-300` | `border-line` |
| `bg-gray-50`, `bg-slate-50` | `bg-canvas` |

`bg-blue-*`, `bg-violet-*`, `bg-purple-*` ve madalya renkleri (`bg-amber-500` /
`bg-gray-400` / `bg-amber-700`) otomatik değiştirilmez — bunlar dekoratif ve kaldırılacak;
ekran dönüşümünde tek tek ele al.

---

## Adım 1 — Primitifler (yarım gün)

`components/ui/` klasörünü kopyala. Sonra `app/layout.tsx` içinde `ToastProvider` ile sarmala:

```tsx
import { ToastProvider } from '@/components/ui'
// …
<body className={`${geistSans.variable} ${geistMono.variable} font-sans`}>
  <ToastProvider>{children}</ToastProvider>
</body>
```

Bileşenler:

| Dosya | Ne verir |
| --- | --- |
| `buttonStyles.ts` | Button ve LinkButton'ın paylaştığı varyant/boyut haritaları |
| `Button.tsx` | 4 varyant, 3 boyut, `loading` (etiket değişmez, spinner gelir) |
| `LinkButton.tsx` | Aynı görünüm, `<Link>` olarak — "link gibi düğme" her yerde var |
| `Field.tsx` | `Field` (etiket + hata altta), `Input` (`align`, `suffix`), `Select` (lucide chevron) |
| `Badge.tsx` | `tone`: neutral / good / warn / bad |
| `Card.tsx` | `Card`, `CardHeader`, `CardBody`, `Metric` |
| `PageHeader.tsx` | Kırıntı yolu + başlık + bağlam satırı + eylem yuvası |
| `DataTable.tsx` | Sıralama, sabit başlık, yoğunluk, iskelet yükleme, boş durum, toolbar/footer |
| `EmptyState.tsx` | Neden + sonraki adım |
| `Toast.tsx` | `useToast().success/error`; başarı 4 sn, hata 8 sn |
| `lib/ui/tone.ts` | `effTone`, `fpqTone`, `tierTone` + ton→sınıf haritaları |

### Eşikleri tek yere topla

`effTone()` artık tek kaynak. Şu dosyalardaki gömülü `>= 90 / >= 75` karşılaştırmalarını sil
ve bunu kullan:

- `app/pes/page.tsx` (Son Dönem Üretim listesi)
- `app/pes/compare/page.tsx`
- `app/pes/reports/page.tsx`
- `components/pes/DashboardCharts.tsx`

---

## Adım 2 — Referans ekran: Atölyeler (1 saat)

`app/pes/workshops/page.tsx` + `components/pes/WorkshopsTable.tsx` dosyalarını kopyala ve
çalıştır. Veri katmanı hiç değişmedi: aynı `withServerTenant`, aynı SQL, aynı istek-yerel
state. Değişenler:

- `max-w-6xl` kalktı → tablo ekranı tam genişlik.
- Başlık/eylem bloğu `PageHeader`'a taşındı.
- Tablo `DataTable`'a taşındı: sıralama, arama, yoğunluk anahtarı, iskelet.
- Tip rozeti maviden nötre döndü (tip bir sınıflandırma, durum değil).
- Ham Supabase hata metni arayüzden çıktı; kullanıcıya tek cümle, detay `console.error`'a.

### ⚠ Server / client sınırı

`DataTable` bir client component ve `columns[].render` birer fonksiyon. **Fonksiyonlar server
component'ten client component'e prop olarak geçemez.** Kalıp şu:

- **Server sayfası:** veriyi çeker, `PageHeader`'ı basar, düz satırları alt bileşene verir.
- **İnce client sarmalayıcı** (`…Table.tsx`): kolon tanımlarını ve arama/yoğunluk state'ini tutar.

Zaten `'use client'` olan ekranlarda (scoring, compare, models…) buna gerek yok, kolonları
doğrudan sayfada tanımla.

---

## Adım 3 — Kabuk (yarım gün)

`components/pes/PesDevSidebar.tsx`:

1. **İkonları lucide'a al.** Şu anda emoji (🛡 🗓 👥 📊), unicode glif (▦ ⊞ ⊿ ◫) ve düz
   karakter (₺ ?) karışık. Hepsi `size-4`, `strokeWidth={1.8}`.
2. **Grupları yeniden böl.** "Performans & Karşılaştırma" 10 madde taşıyor ve içine ait
   olmayanları almış. Öneri:
   - **Operasyon** — Dashboard, Atölyeler, Takvim, Üretim, İş Emirleri
   - **Veri girişi** — Üretim, Kalite, Duruş, Gider, Changeover, Gider Yükle
   - **Analiz** — Skorlama, Karşılaştırma, Benchmark, Yetenek Raporu, Veri Kalitesi
   - **Modelleme** — Modeller, Süreçler, VSM / Simülasyon, Fiyatlama
   - **Referans** — Sözlük, Referans, Fiyat Endeksleri, Beyan Geçmişi, Raporlar
3. **`Dev Mode` etiketini koşula bağla:** `{process.env.NODE_ENV !== 'production' && …}`
4. **Alta kimlik bloğu:** kullanıcı e-postası, tenant adı, Çıkış. Şu anda kullanıcı kim
   olduğunu ve nasıl çıkacağını göremiyor.

Aynı düzenlemeler `WorkshopSidebar.tsx` için de geçerli; iki sidebar aynı `NavGroup` tipini
ve aynı satır bileşenini paylaşmalı.

### Dönem seçimi üst bara

Şu ekranların her biri kendi yıl/ay `<select>`'ini taşıyor ve durum paylaşılmıyor:
`scoring`, `production`, `quality`, `costs`, `compare`, `benchmark`.

Kullanıcı Mart'a bakarken Kalite'ye geçince sessizce Ağustos'a dönüyor — analitik bir
üründe bu veri güvenilirliği sorunu.

Çözüm: `app/pes/layout.tsx` içine ince bir üst bar; dönem `?donem=2026-03` olarak URL'de
tutulur, ekranlar `useSearchParams()` / `searchParams` ile okur. Yıl listesi sabit
`2025 / 2026` değil, veriden gelir.

---

## Adım 4 — Kalan ekranlar

Sırayla; her adım bir öncekinin kalıbını doğruluyor:

1. **Skorlama** — sıralama + `tierTone` + dönem seçimi burada sınanır.
2. **Üretim / Kalite / Maliyet** — üç form ekranı; `Field` ızgarası ve `useToast()`.
   Kalıcı yeşil `message` div'lerini toast'a çevir; `w-full` input'ları içeriğe göre daralt.
3. **Compare / Benchmark / Reports** — dekoratif mavi/mor ve madalya renkleri kalkar,
   `effTone` gelir.
4. **Diğer liste ekranları** — processes, downtime, changeover, models.
5. **Takvim ve Fiyatlama** — en sona. En yoğun iki ekran, kendi özel kuralları var;
   `text-[9px]` / `text-[10px]` kullanımları 11px alt sınırına çekilir.

---

## Adım 5 — Pano

`app/pes/page.tsx` şu anda ölçüyor ama yönlendirmiyor. "Aktif Atölye: 12" bir yöneticinin
sabah ilk sorusu değil.

- En üste **"Dikkat gerektirenler"**: eşiğin altına düşen atölyeler, gecikme riski olan iş
  emirleri, eksik gider beyanları. Her satır ilgili ekrana gider.
- Dört sayım kartı, başlığın altında ince bir metin şeridine iner.
- **Hızlı Erişim ızgarası kalkar** — kenar çubuğunu tekrar ediyor.

---

## Bitince

- `globals.css`'teki `--color-pes-accent` alias'larını sil.
- `grep -r "#197A56" app components` → boş dönmeli.
- `grep -rE "slate-[0-9]" app components` → boş dönmeli (VSIM hariç).
- `grep -rE "text-\[(9|10)px\]" app components` → boş dönmeli.
